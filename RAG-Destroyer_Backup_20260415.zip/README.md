<div align="center">
  <h1>🚀 RAG-Destroyer (Orchestrator v1.0)</h1>
  <p><b>A High-Performance, Vector-Free RAG Engine with Obsidian Integration & Parallel AI Bots</b></p>
</div>

<br>

## 💡 1. The "Lom RAG" Philosophy
**The Problem:** Traditional RAG systems rely on complex Vector Databases (Pinecone, Weaviate, etc.) which introduce high latency, cost, and "black box" embedding issues. Managing indices for enterprise data is often overkill and hard to audit.

**The Solution:** **RAG-Destroyer** eliminates the Vector DB entirely. It treats your **Obsidian Vault** (on Google Drive) as the primary "Librarian". It uses a multi-threaded swarm of AI bots to perform keyword-based subset searches, achieving massive throughput and 100% explainability.

---

## 🏗️ 2. System Architecture
The system is built on a **Massively Parallel Orchestration Layer** that separates query interpretation from data retrieval.

### 🏗️ 2.1 The 4-Bot Parallel Pipeline
1. **Refinery Agent**: Cleans raw data and intelligently renames files in the vault.
2. **Interpreter Agent**: Converts natural language into a swarm of optimized search keywords.
3. **Search Workers (x4 Bots)**: Parallel threads that scan the Obsidian vault using metadata, tags, and content matching.
4. **Subset Calculator**: Intersects search results to find the "Best Subset" of documents.
5. **Administrator Agent**: Final synthesis and "Linguistic Guard" audit for professional Thai output.

---

## ⚖️ 3. Key Features
- **🌐 Obsidian Control**: Use Obsidian as your storage control center. Full support for YAML Frontmatter, #Tags, and [[Internal Links]].
- **⚡ Parallel Search Bots**: 4 simultaneous workers quadruple the search coverage without the need for embeddings.
- **🛡️ Department Subsets**: Built-in access control based on user departments (RBAC).
- **📥 Smart Exporter**: One-click export to Docx/PDF while preserving original vault integrity (Copy-only policy).
- **🇹🇭 Linguistic Guard**: Ensures all AI-generated answers are naturally phrased Thai, free from robot-talk.

---

## 🚀 4. Quick Start

### Installation
```bash
git clone https://github.com/vittaya1973/RAG-Destroyer.git
cd RAG-Destroyer
pip install -r requirements.txt
```

### Configuration
Update `config/.env` with your API keys:
```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
```

### Run the UI
```bash
streamlit run app.py
```

---

## 📊 5. Tech Stack
| Category | Technology | Purpose |
| :--- | :--- | :--- |
| **Orchestration** | `Python 3.9+` | Core control logic |
| **Logic Layer** | `Gemini 2.5 Flash` | Query interpretation & response synthesis |
| **Storage** | `Obsidian (Markdown + Folder)` | Distributed knowledge vault |
| **UI Framework** | `Streamlit` | Premium data dashboard |
| **Parallelization**| `concurrent.futures` | 4-thread parallel search bots |

<br>

---
*📍 **Developer Note:** "RAG-Destroyer is built for those who value speed, auditability, and simplicity. By moving back to a code-based librarian approach powered by modern LLMs, we regain control over our data without the overhead of vector infrastructure."*
