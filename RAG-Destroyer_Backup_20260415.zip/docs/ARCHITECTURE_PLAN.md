# implementation_plan.md - RAG-Destroyer (ล้ม RAG)

## เป้าหมาย
## เป้าหมาย
สร้าง **"RAG-Destroyer" (Orchestrator v1.0)** ระบบจัดการความรู้สมรรถนะสูงที่ใช้การค้นหาแบบ **Parallel Search (4-Worker Bots)** และระบบควบคุมการเข้าถึงข้อมูลตาม **Department Subset** โดยไม่อิง Vector Database

## User Review Required
> [!IMPORTANT]
> **Parallel Search Architecture**: ระบบจะใช้ "Search Bots" 3-4 ตัวทำงานพร้อมกันเพื่อหาเอกสารตาม Keywords ที่ Orchestrator สร้างขึ้น เพื่อความรวดเร็วและครอบคลุม
> **Access Control (Subset)**: ข้อมูลใน Obsidian จะถูกแบ่งกลุ่มตามแผนกหรือบุคคล การค้นหาจะถูกจำกัดวง (Scope) เฉพาะ Subset ที่ผู้ใช้มีสิทธิ์เข้าถึงเท่านั้น ไม่มีการค้นหาข้ามแผนกหากไม่ได้รับอนุญาต
> **Subset Calculation**: ระบบจะใช้ตรรกะทางคณิตศาสตร์ในการหาผลร่วม (Intersection) ของเอกสารที่บอทแต่ละตัวหามาได้ เพื่อให้ได้ "Best Subset" ที่ตรงจุดที่สุดก่อนส่งให้ AI สรุป

## แผนการสร้าง Project

### [ส่วนประกอบหลักของ Lean-RAG]

#### [NEW] [LomRAG_Engine.py](file:///Users/tong/Documents/MyClaw/Lean-RAG/core/LomRAG_Engine.py)
ตัวควบคุมหลัก (Orchestrator) ที่รวมคลาส `Interpreter`, `Librarian`, และ `Administrator` เข้าด้วยกันตามมาตรฐาน SOP

#### [NEW] [Librarian.py](file:///Users/tong/Documents/MyClaw/Lean-RAG/core/Librarian.py)
ตรรกะสำหรับการกรองไฟล์ Markdown (Set intersection, keyword matching) โดยไม่อิง Vector search

#### [NEW] [Refinery.py](file:///Users/tong/Documents/MyClaw/RAG-Destroyer/core/Refinery.py)
ระบบจัดการ Raw Data: อ่านไฟล์จาก `raw_data/`, ใช้ Gemini ช่วย Clean เนื้อหา, ตั้งชื่อไฟล์ (Smart Naming), และบันทึกลง Obsidian Vault

#### [NEW] [RAG_Orchestrator.py](file:///Users/tong/Documents/MyClaw/RAG-Destroyer/core/Orchestrator.py)
ตัวควบคุมหลัก: รับคำขอ -> Gen Keywords -> สั่งการบอท 4 ตัวค้นหา -> คำนวณ Subset -> ส่งให้ AI กรองขั้นสุดท้าย

#### [NEW] [SearchBot_Worker.py](file:///Users/tong/Documents/MyClaw/RAG-Destroyer/core/SearchWorker.py)
Code Bot ขนาดเล็ก (3-4 instances) ที่ทำงานแบบ Parallel เพื่อค้นหาไฟล์ตามลิสต์ Keywords ภายใต้ข้อจำกัดของ Subset แผนก

#### [NEW] [Obsidian_Librarian.py](file:///Users/tong/Documents/MyClaw/RAG-Destroyer/core/Librarian.py)
ตัวกรองข้อมูลที่เข้าใจโครงสร้างของ Obsidian (Tags, Metadata) เพื่อความแม่นยำสูง

### [การตั้งค่าระบบ]

#### [NEW] [.env](file:///Users/tong/Documents/MyClaw/Lean-RAG/config/.env)
ไฟล์เก็บ API Keys

#### [NEW] [requirements.txt](file:///Users/tong/Documents/MyClaw/Lean-RAG/requirements.txt)
Dependencies: `google-genai`, `python-frontmatter`, `python-dotenv`

## คำถามที่ต้องการคำตอบ (Open Questions)
1. **แหล่งข้อมูล**: ในเวอร์ชันแรก เราจะเน้นไปที่ **Local Markdown directory** ก่อน หรือต้องการให้เชื่อมต่อ **Google Drive** เลยครับ?
2. **หน้าตาโปรแกรม**: ต้องการแบบ **CLI** (หน้าจอดำแบบที่ใช้ใน SynthAsia) หรือต้องการ **Web UI** ง่ายๆ (เช่น Streamlit) ครับ?
3. **มาตรฐานภาษา**: ต้องการให้ใส่ "Linguistic Guard" เพื่อคุมคุณภาพภาษาไทยให้ดูเป็นมืออาชีพเหมือนในโปรเจกต์ SynthAsia ด้วยไหมครับ?

## แผนการทดสอบ (Verification Plan)
### การทดสอบอัตโนมัติ
- `python core/Librarian.py` (ทดสอบการกรองข้อมูล)
- `python core/Interpreter.py` (ทดสอบการวิเคราะห์คำถามเป็น JSON)

### การทดสอบด้วยตัวเอง
- ลองถามคำถามที่เกี่ยวข้องกับข้อมูลตัวอย่าง และตรวจสอบว่าระบบดึงเฉพาะไฟล์ที่เกี่ยวข้องมาตอบจริงๆ หรือไม่
