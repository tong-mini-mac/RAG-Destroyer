import time
import os
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from .Refinery import DataRefinery
from .Utils import CONFIG

class RawDataHandler(FileSystemEventHandler):
    def __init__(self, refinery, department="General"):
        self.refinery = refinery
        self.department = department

    def on_created(self, event):
        if not event.is_directory:
            file_path = event.src_path
            # Avoid processing hidden files or temp files
            if os.path.basename(file_path).startswith("."):
                return
            
            print(f"🔔 Auto-Refinery: New file detected: {file_path}")
            # Wait a moment for file to be fully written (e.g., Google Drive sync)
            time.sleep(2) 
            self.refinery.process_file(file_path, self.department)

class BackgroundMonitor:
    def __init__(self, watch_path=None, department="General"):
        self.watch_path = watch_path or CONFIG["RAW_DATA_PATH"]
        self.department = department
        self.refinery = DataRefinery()
        self.observer = Observer()

    def start(self):
        event_handler = RawDataHandler(self.refinery, self.department)
        self.observer.schedule(event_handler, self.watch_path, recursive=False)
        self.observer.start()
        print(f"👀 Monitor started on: {self.watch_path}")

    def stop(self):
        self.observer.stop()
        self.observer.join()
