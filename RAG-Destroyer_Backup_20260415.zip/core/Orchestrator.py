import concurrent.futures
import json
from .Utils import GeminiClient, extract_json, CONFIG
from .SearchWorker import SearchWorker

class RAGOrchestrator:
    def __init__(self, vault_path=None):
        self.vault_path = vault_path or CONFIG["CLEANED_DATA_PATH"]
        self.ai = GeminiClient()
        self.worker = SearchWorker(self.vault_path)

    def generate_keywords(self, query):
        """Uses AI to generate 3-4 distinct search keywords from the query."""
        system_instruction = """
        You are the 'RAG-Destroyer Keyword Generator'.
        Target: Convert a complex user request into 3-4 distinct, high-impact search keywords in Thai.
        Format: Return a JSON list of strings.
        Example: "ขอสถิติการขายของแผนกบัญชีปี 2024" -> ["สถิติการขาย", "บัญชี", "2024", "สรุปยอด"]
        """
        raw = self.ai.call(query, system_instruction=system_instruction, json_mode=True)
        try:
            return json.loads(extract_json(raw))
        except:
            return [query] # Fallback

    def execute_search(self, keywords, allowed_subsets):
        """Spawns parallel search workers for each keyword."""
        all_results = []
        
        # Parallel execution of SearchWorker for each keyword
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            future_to_kw = {executor.submit(self.worker.search, kw, allowed_subsets): kw for kw in keywords}
            for future in concurrent.futures.as_completed(future_to_kw):
                kw = future_to_kw[future]
                try:
                    res = future.result()
                    all_results.append({"keyword": kw, "hits": res})
                except Exception as e:
                    print(f"Worker for '{kw}' failed: {e}")
        
        return all_results

    def calculate_best_subset(self, search_results):
        """
        Calculates the best subset of documents.
        Logic: Documents that appear in multiple keyword searches get higher priority.
        Intersection logic.
        """
        doc_map = {} # path -> {doc_info, count}
        
        for item in search_results:
            for hit in item["hits"]:
                path = hit["path"]
                if path not in doc_map:
                    doc_map[path] = hit
                    doc_map[path]["hit_count"] = 1
                else:
                    # Boost relevance if found by multiple keywords
                    doc_map[path]["relevance"] += hit["relevance"]
                    doc_map[path]["hit_count"] += 1

        # Sort by hit_count (intersections) first, then relevance
        sorted_docs = sorted(doc_map.values(), key=lambda x: (x["hit_count"], x["relevance"]), reverse=True)
        return sorted_docs[:5] # Top 5 documents

    def final_synthesis(self, query, context_docs):
        """Final AI synthesis using the best subset of context."""
        if not context_docs:
            return "ไม่พบเอกสารที่เกี่ยวข้องในแผนกของคุณครับ"

        # Prepare context text
        context_text = ""
        for i, doc in enumerate(context_docs):
            try:
                with open(doc["path"], 'r', encoding='utf-8') as f:
                    content = f.read()
                    context_text += f"\n--- DOCUMENT {i+1}: {doc['title']} ---\n{content}\n"
            except: continue

        system_instruction = """
        You are the 'RAG-Destroyer Administrator'.
        Mission: Answer the user's request using EXCLUSIVELY the provided context documents.
        Quality: Professional Thai, clear, concise. Using the 'Linguistic Guard' standard.
        If the answer is not in the context, say you don't know based on the accessible documents.
        """
        
        prompt = f"User Request: {query}\n\nContext Documents:\n{context_text}"
        return self.ai.call(prompt, system_instruction=system_instruction)

    def handle_request(self, query, user_department):
        """Main entry point for a query."""
        print(f"🔍 Orchestrating: '{query}' for dept: {user_department}")
        
        # 1. Gen Keywords
        keywords = self.generate_keywords(query)
        print(f"🔑 Keywords: {keywords}")
        
        # 2. Parallel Search (Limited by department subset)
        search_results = self.execute_search(keywords, [user_department])
        
        # 3. Calculate Subset (Intersection/Ranking)
        best_subset = self.calculate_best_subset(search_results)
        print(f"📊 Best Subset found: {len(best_subset)} docs")
        
        # 4. Final Synthesis
        answer = self.final_synthesis(query, best_subset)
        
        return {
            "answer": answer,
            "sources": best_subset
        }
