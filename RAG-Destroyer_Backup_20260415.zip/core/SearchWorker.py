import os
import re
import frontmatter

class SearchWorker:
    """A bot that searches for a specific keyword within an authorized subset of the vault."""
    
    def __init__(self, vault_path="knowledge"):
        self.vault_path = vault_path

    def search(self, keyword, allowed_subsets=None):
        """
        Searches for a keyword in files.
        allowed_subsets: List of folder names OR "ALL".
        """
        if not allowed_subsets:
            return []

        results = []
        keyword = keyword.lower()
        
        # Determine actual folders to search
        target_dirs = []
        if allowed_subsets == "ALL":
            target_dirs = [d for d in os.listdir(self.vault_path) 
                          if os.path.isdir(os.path.join(self.vault_path, d)) and not d.startswith(".")]
        else:
            target_dirs = allowed_subsets

        for subset in target_dirs:
            subset_dir = os.path.join(self.vault_path, subset)
            if not os.path.exists(subset_dir):
                continue

            for root, dirs, files in os.walk(subset_dir):
                for file in files:
                    if file.endswith(".md"):
                        file_path = os.path.join(root, file)
                        try:
                            # Use python-frontmatter to parse YAML
                            post = frontmatter.load(file_path)
                            content = post.content.lower()
                            title = post.get("title", file).lower()
                            tags = str(post.get("tags", [])).lower()
                            
                            # Simple keyword matching
                            # In a real scenario, we might use Regex or TF-IDF
                            relevance = 0
                            if keyword in title:
                                relevance += 5
                            if keyword in tags:
                                relevance += 3
                            if keyword in content:
                                relevance += 1
                                # Count occurrences
                                relevance += content.count(keyword) * 0.1
                            
                            if relevance > 0:
                                results.append({
                                    "path": file_path,
                                    "title": post.get("title", file),
                                    "relevance": relevance,
                                    "department": subset,
                                    "tags": post.get("tags", [])
                                })
                        except Exception as e:
                            print(f"Error reading {file_path}: {e}")
        
        return results
