import os
import re
import json
import time
from google import genai
from google.genai import types
from dotenv import load_dotenv

# Load Environment
def load_env_config():
    env_path = os.path.join(os.path.dirname(__file__), "..", "config", ".env")
    load_dotenv(env_path)
    
    # Google Drive Paths
    gdrive_root = "/Users/tong/Library/CloudStorage/GoogleDrive-vittaya1973@gmail.com/My Drive/RAG-Destroyer"
    
    return {
        "GEMINI_API_KEY": os.getenv("GEMINI_API_KEY"),
        "GEMINI_MODEL": os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        "RAW_DATA_PATH": os.getenv("RAW_DATA_PATH", os.path.join(gdrive_root, "raw data")),
        "CLEANED_DATA_PATH": os.getenv("CLEANED_DATA_PATH", os.path.join(gdrive_root, "cleaned data"))
    }

CONFIG = load_env_config()

def safe_ai_call(func, *args, max_retries=3, **kwargs):
    """Safe wrapper for AI calls with exponential backoff."""
    for attempt in range(max_retries):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            err_msg = str(e).lower()
            if any(x in err_msg for x in ["429", "rate limit", "too many requests"]):
                wait = (2 ** attempt) + 1
                time.sleep(wait)
            elif attempt < max_retries - 1:
                time.sleep(1)
            else:
                raise e
    return None

def extract_json(text):
    """Extracts JSON from a string."""
    match = re.search(r'(\{.*\}|\[.*\])', text, re.DOTALL)
    return match.group(0) if match else text

class GeminiClient:
    def __init__(self):
        self.api_key = CONFIG["GEMINI_API_KEY"]
        self.model = CONFIG["GEMINI_MODEL"]
        self.client = genai.Client(api_key=self.api_key)

    def call(self, prompt, system_instruction=None, json_mode=False):
        def _call():
            config = types.GenerateContentConfig(
                temperature=0.2,
                system_instruction=system_instruction
            )
            if json_mode:
                config.response_mime_type = "application/json"
            
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt,
                config=config
            )
            return response.text
        return safe_ai_call(_call)
