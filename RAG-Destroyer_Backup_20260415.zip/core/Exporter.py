import os
import shutil
from docx import Document
# from reportlab.lib.pagesizes import letter
# from reportlab.pdfgen import canvas

class FileExporter:
    def __init__(self, output_dir="output"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def export_to_docx(self, markdown_path, target_name=None):
        """Converts Markdown to a simple Docx file."""
        if not os.path.exists(markdown_path):
            return None
            
        with open(markdown_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Simple conversion (strip YAML frontmatter)
        if content.startswith("---"):
            parts = content.split("---", 2)
            if len(parts) >= 3:
                content = parts[2].strip()

        doc = Document()
        # Basic parsing (just heads and text for now)
        for line in content.split("\n"):
            if line.startswith("# "):
                doc.add_heading(line[2:], 0)
            elif line.startswith("## "):
                doc.add_heading(line[3:], 1)
            elif line.startswith("### "):
                doc.add_heading(line[4:], 2)
            else:
                doc.add_paragraph(line)

        target_name = target_name or os.path.basename(markdown_path).replace(".md", ".docx")
        if not target_name.endswith(".docx"):
            target_name += ".docx"
            
        save_path = os.path.join(self.output_dir, target_name)
        doc.save(save_path)
        return save_path

    # ... Excel / PDF methods could be added here later ...
