import streamlit as st
import os
import time
from core.Refinery import DataRefinery
from core.Orchestrator import RAGOrchestrator
from core.Exporter import FileExporter
from core.Monitor import BackgroundMonitor
from core.VaultWarden import VaultWarden
from core.Utils import CONFIG
import threading

# Page Config
st.set_page_config(page_title="RAG-Destroyer", page_icon="🚀", layout="wide")

# Initialize Sessions
if "orchestrator" not in st.session_state:
    st.session_state.orchestrator = RAGOrchestrator()
if "refinery" not in st.session_state:
    st.session_state.refinery = DataRefinery()
if "exporter" not in st.session_state:
    st.session_state.exporter = FileExporter()
if "monitor" not in st.session_state:
    st.session_state.monitor = BackgroundMonitor()
    # Start monitor in background thread
    monitor_thread = threading.Thread(target=st.session_state.monitor.start, daemon=True)
    monitor_thread.start()
    st.session_state.monitor_running = True
if "warden" not in st.session_state:
    st.session_state.warden = VaultWarden()

st.title("🚀 RAG-Destroyer (Lom RAG)")
st.markdown("### High-Performance Parallel Search & Zero-Vector-DB Knowledge Vault")

# Sidebar - Settings & Department
st.sidebar.header("⚙️ Settings")
user_role = st.sidebar.selectbox("Your Role", ["Executive", "Manager", "Staff"])
department = st.sidebar.selectbox("Select Department / Subset", ["Human Resources", "Accounting", "Marketing", "Sales", "Operations", "IT", "General"])

# Determine allowed subsets for search
if user_role == "Executive":
    allowed_search_subsets = "ALL"
    st.sidebar.success("👑 Executive Access: Search All Subsets")
else:
    allowed_search_subsets = [department]
    st.sidebar.info(f"📁 Limited Search: {department}")

# --- Phase 1: Ingest & Refinery ---
st.sidebar.divider()
st.sidebar.header("📥 Ingest Raw Data")
uploaded_files = st.sidebar.file_uploader("Upload Raw Documents", accept_multiple_files=True)

if st.sidebar.button("💎 Run Refinery"):
    if uploaded_files:
        raw_dir = CONFIG["RAW_DATA_PATH"]
        os.makedirs(raw_dir, exist_ok=True)
        for uploaded_file in uploaded_files:
            file_path = os.path.join(raw_dir, uploaded_file.name)
            with open(file_path, "wb") as f:
                f.write(uploaded_file.getbuffer())
            
            with st.spinner(f"Refining {uploaded_file.name}..."):
                st.session_state.refinery.process_file(file_path, department)
        st.sidebar.success("Refinery process complete!")
    else:
        st.sidebar.warning("Please upload files first.")

# --- Phase 3: Vault Maintenance ---
st.sidebar.divider()
st.sidebar.header("🛡️ Vault Maintenance")
if st.sidebar.button("🗃️ Update Master Index"):
    with st.spinner("Warden is auditing the vault..."):
        st.session_state.warden.audit_and_index()
    st.sidebar.success("Master Index updated!")

# --- Phase 2: Search & Orchestration ---
st.header("🔍 Search Vault")
query = st.text_input("Enter your request (Thai/English):", placeholder="เช่น สรุปรายงานการขายของเดือนที่แล้ว")

if st.button("🚀 Search"):
    if query:
        with st.spinner("Orchestrating search bots..."):
            result = st.session_state.orchestrator.handle_request(query, allowed_search_subsets)
            
            st.divider()
            st.markdown(f"### 🤖 Answer:\n{result['answer']}")
            
            if result['sources']:
                st.markdown("### 📚 Source Documents:")
                cols = st.columns(len(result['sources']))
                for i, doc in enumerate(result['sources']):
                    with cols[i]:
                        st.info(f"**{doc['title']}**\n\nRel: {doc['relevance']}")
                        if st.button(f"📥 Export Docx", key=f"exp_{i}"):
                            output_path = st.session_state.exporter.export_to_docx(doc['path'])
                            with open(output_path, "rb") as f:
                                st.download_button(
                                    label="Click to Download",
                                    data=f,
                                    file_name=os.path.basename(output_path),
                                    mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                )
            else:
                st.warning("No relevant documents found in this subset.")
    else:
        st.error("Please enter a query.")
